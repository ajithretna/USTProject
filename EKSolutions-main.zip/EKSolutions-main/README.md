# EKSolutions
Solution created to read data from JSon file and Update the file 
