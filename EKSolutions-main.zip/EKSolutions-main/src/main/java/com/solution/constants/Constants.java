package com.solution.constants;

import org.springframework.stereotype.Component;

@Component
public class Constants {
	public static final String APPNAMETAG = "appName";
	public static final String APPPATHTAG = "appPath";
	public static final String APPOWNERTAG = "appOwner";
	public static final String ISVALID = "isValid";
	public static final String APPDATATAG = "appData";
	

}
