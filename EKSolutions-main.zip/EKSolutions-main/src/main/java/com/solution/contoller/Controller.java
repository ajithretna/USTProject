package com.solution.contoller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import com.solution.service.ServiceLayer;
import com.solution.util.AppName;
import java.util.*;

@RestController
@RequestMapping("/internal")
public class Controller {
	@Autowired
	private ServiceLayer  serviceLayer;

	@GetMapping("/apps")
	public ResponseEntity<List<AppName>> getAppsList() {
		return ResponseEntity.ok().body(serviceLayer.getAppsFromFile());
	}

	@PostMapping("/apps")
	public ResponseEntity<List<AppName>> updateAppsList(@RequestBody List<AppName> appNameList) {
		serviceLayer.updateAppsToFile(appNameList);
		return ResponseEntity.status(HttpStatus.CREATED).body(null);
	}

	@DeleteMapping("/apps")
	public ResponseEntity<List<AppName>> deleteAppsList(@RequestBody List<AppName> appName) {
		serviceLayer.deleteAppsFromFile(appName);
		return ResponseEntity.status(HttpStatus.ACCEPTED).body(null);
	}


}
