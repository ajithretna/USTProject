package com.solution.service;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.solution.constants.Constants;
import com.solution.exception.ApplicationException;
import com.solution.util.AppData;
import com.solution.util.AppName;

@Service
public class ServiceLayer {

	@Autowired
	private Constants constants;

	private static String filePathKey = "Please poulate the path beofre RUn";

	public List<AppName> getAppsFromFile() {
		List<AppName> actualListFromFile = new ArrayList<>();
		try {
			actualListFromFile = readFromFile(actualListFromFile);
		} catch (Exception E) {
			throw new ApplicationException("Application Error Occured.");
		}
		return actualListFromFile;
	}

	public void updateAppsToFile(List<AppName> appNameList) {
		List<AppName> actualListFromFile = new ArrayList<>();

		try {
			actualListFromFile = readFromFile(actualListFromFile);
			readAndWriteTofile(actualListFromFile, appNameList);

		} catch (Exception E) {
			throw new ApplicationException("Application Error Occured.");
		}
	}

	public void deleteAppsFromFile(List<AppName> appNameList) {
		List<AppName> actualListFromFile = new ArrayList<>();

		try {
			actualListFromFile = readFromFile(actualListFromFile);
			deleteAndWriteTofile(actualListFromFile, appNameList);
		} catch (Exception E) {
			throw new ApplicationException("Application Error Occured.");
		}

	}

	private List<AppName> readFromFile(List<AppName> actualListFromFile) {
		try {
			ObjectMapper mapper = new ObjectMapper();
			actualListFromFile = mapper.readValue(new File(filePathKey),
					new TypeReference<List<AppName>>() {
					});

		} catch (Exception E) {
			throw new ApplicationException("Application Error Occured.");
		}
		return actualListFromFile;
	}

	private void readAndWriteTofile(List<AppName> actualListFromFile, List<AppName> appNameListFromRequest) {
		JSONArray appDataFile = new JSONArray();
		Map<String, AppData> originalFileData = actualListFromFile.stream()
				.collect(Collectors.toMap(AppName::getAppName, AppName::getAppData));
		for (AppName appName : appNameListFromRequest) {
			if (originalFileData.containsKey(appName.getAppName())) {
				AppData appDatamodified = originalFileData.get(appName.getAppName());
				appDatamodified.setAppOwner(appName.getAppData().getAppOwner());
				appDatamodified.setValid(appName.getAppData().isValid());
				originalFileData.put(appName.getAppName(), appDatamodified);
			} else {
				AppData newAppDataValue = new AppData();
				newAppDataValue.setAppPath(appName.getAppData().getAppPath());
				newAppDataValue.setAppOwner(appName.getAppData().getAppOwner());
				newAppDataValue.setValid(appName.getAppData().isValid());
				originalFileData.put(appName.getAppName(), newAppDataValue);
			}
		}

		for (var entry : originalFileData.entrySet()) {
			JSONObject appNameValue = new JSONObject();
			appNameValue.put(constants.APPNAMETAG, entry.getKey().toString());
			JSONObject appDataValue = new JSONObject();
			appDataValue.put(constants.APPPATHTAG, entry.getValue().getAppPath());
			appDataValue.put(constants.APPOWNERTAG, entry.getValue().getAppOwner());
			appDataValue.put(constants.ISVALID, entry.getValue().isValid());
			appNameValue.put(constants.APPDATATAG, appDataValue);
			appDataFile.add(appNameValue);

		}
		try (FileWriter file = new FileWriter(filePathKey)) {
			file.write(appDataFile.toJSONString());
			file.flush();
		} catch (IOException e) {
			throw new ApplicationException("Application Error Occured.");
		}
	}

	private void deleteAndWriteTofile(List<AppName> actualListFromFile, List<AppName> appNameListFromRequest) {
		JSONArray appDataFile = new JSONArray();
		Map<String, AppData> originalFileData = actualListFromFile.stream()
				.collect(Collectors.toMap(AppName::getAppName, AppName::getAppData));
		for (AppName appName : appNameListFromRequest) {
			if (originalFileData.containsKey(appName.getAppName())) {
				originalFileData.remove(appName.getAppName());
			}
		}

		for (var entry : originalFileData.entrySet()) {
			JSONObject appNameValue = new JSONObject();
			appNameValue.put(constants.APPNAMETAG, entry.getKey().toString());
			JSONObject appDataValue = new JSONObject();
			appDataValue.put(constants.APPPATHTAG, entry.getValue().getAppPath());
			appDataValue.put(constants.APPOWNERTAG, entry.getValue().getAppOwner());
			appDataValue.put(constants.ISVALID, entry.getValue().isValid());
			appNameValue.put(constants.APPDATATAG, appDataValue);
			appDataFile.add(appNameValue);

		}
		try (FileWriter file = new FileWriter(filePathKey)) {
			file.write(appDataFile.toJSONString());
			file.flush();
		} catch (IOException e) {
			throw new ApplicationException("Application Error Occured.");
		}

	}
}
