package com.solution.util;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonFormat.Shape;

public class AppData {
	private String appPath;
	private String appOwner;
	@JsonFormat(shape = Shape.BOOLEAN)
	private boolean isValid;

	
	@Override
	public String toString() {
		return "[appPath=" + appPath + ", appOwner=" + appOwner + ", isValid=" + isValid + "]";
	}

	public boolean isValid() {
		return isValid;
	}

	public void setValid(boolean isValid) {
		this.isValid = isValid;
	}

	public String getAppPath() {
		return appPath;
	}

	public void setAppPath(String appPath) {
		this.appPath = appPath;
	}

	public String getAppOwner() {
		return appOwner;
	}

	public void setAppOwner(String appOwner) {
		this.appOwner = appOwner;
	}

	

}
