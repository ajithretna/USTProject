package com.example.contoller;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;

import com.solution.contoller.Controller;
import com.solution.util.AppName;

@SpringBootTest
@RunWith(SpringRunner.class)
@WebMvcTest(value= Controller.class)
class DemoApplicationTests {
	
	@Autowired
	private MockMvc mockmvc;
	
	@MockBean
	Controller conroller;

	@Test
	public void testGetApps() {
		List<AppName> actualList = new ArrayList<>();
		//to be covered 
	}
}
