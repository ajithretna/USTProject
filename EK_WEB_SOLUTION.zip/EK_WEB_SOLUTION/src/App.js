import { ThemeProvider, createTheme } from '@mui/material';
import './styling/App.css';
import RequestForm from './components/RequestForm';

const theme = createTheme({
  palette: {
    mode: 'dark',
    primary: {
      main: '#f50057',
    },
  },
});


function App() {
  return (
    <ThemeProvider theme={theme}>
      <div className="App">
        <div className='App-header'></div>
        <RequestForm/>
      </div>
    </ThemeProvider>
  );
}

export default App;
