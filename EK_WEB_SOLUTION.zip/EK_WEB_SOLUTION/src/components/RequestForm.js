import { InputLabel, Input, Grid, TextField, Button, Item } from '@mui/material';
import { useRef, useState } from 'react';

async function sendRequest(requestType, payload) {
	
  let response = await fetch('http://localhost:8082/internal/apps', {
    method: 'GET',
    mode: "no-cors",
    headers: {
      'Accept': '*/*',
	  'Access-Control-Allow-Origin': 'http://localhost:8082/'
    }
  });
  console.log(response);
  return response.appName;
};

function RequestForm() {
  const payload = useRef();
  const requestType = useRef();
  const [response, setResponse] = useState();

  const defaultPayload = JSON.stringify({
    "contacts": [
      {
        "id": "MAINCONTACT_1",
        "person": {
          "names": [
            {
              "type": "CURRENT",
              "firstName": "Paul",
              "surName": "Buttivant"
            }
          ]
        },
        "addresses": [
          {
            "addressType": "CURRENT",
            "buildingNumber": "19",
            "postal": "AL4 9EL"
          }
        ]
      }
    ],
    "application": {
      "applicants": [
        {
        "contactId": "MAINCONTACT_1",
        "applicantType": "APPLICANT",
        "id": "APPLICANT_1",
        "consent": true
        }
      ]
    }
  }, undefined, 4);

  return (
    <>
      <Grid id='Form'>
        <InputLabel htmlFor="request-type" style={{ fontSize: 20 }}>Request Type</InputLabel>
        <Input id="request-type" aria-describedby="SIMPLE FRONT END APP" inputRef={requestType} defaultValue="GET APPS PAGE"/>
      </Grid>
      <Grid container spacing={2} id='Form' style={{justifyContent: 'space-evenly', height: '70vh'}}>
        <Grid item id='Button' style={{ margin: 'auto'}}>
        <Button variant="outlined" size="large" style={{ fontSize: 20 }} onClick={async _ => setResponse(await sendRequest(requestType.current?.value, payload.current?.value))}>GETRESPONSE</Button>
      </Grid>
        <Grid item style={{ padding: '10', width: "40%", margin: 'auto' }}>
          <h2 htmlFor="response" >Response</h2>
          <TextField multiline fullWidth id="response" aria-describedby="response" rows={30} inputProps={{ readOnly: true }} value={response}/>
        </Grid>
      </Grid>
    </>
  );
}
export default RequestForm;
